package ToDoList;

import javax.swing.*;
import java.awt.*;
public class List extends JPanel {
    List(){
        GridLayout layout = new GridLayout(10,1);
        layout.setVgap(5);
        this.setLayout(layout);
        this.setBackground(new Color(131,162,212));
    }

    public void updateNumbers(){
        Component[] listItems = this.getComponents();
int i;
        for(i = 0;i < listItems.length;i++){
            if(listItems[i] instanceof Task){
                ((Task)listItems[i]).changeIndex(i+1);
            }
        }
    }
}
