package ToDoList;

public class ToDoList {
    public static void main(String[] args){
        new AppFrame();
    }
}
